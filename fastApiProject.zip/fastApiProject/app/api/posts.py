# app/api/posts.py
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status, Query
from sqlmodel import Session

from ..database import get_session
from ..models.users import User
from ..models.posts import PostCreate, PostRead, Post # 确保Post模型导入
from ..services.auth_service import get_current_active_user
from ..services.post_service import (
    db_create_post,
    db_get_post_by_id,
    db_get_posts,
    db_add_favorite,
    db_remove_favorite,
    db_get_user_favorites,
    db_is_user_favor_post,
    db_upload_file_generic # 如果需要独立上传接口
)

router = APIRouter(prefix="/posts", tags=["Posts"])

@router.post("/", response_model=PostRead, summary="创建新帖子 (可附带文件)")
async def create_new_post_api(
    title: str = Form(...),
    content: str = Form(...),
    file: Optional[UploadFile] = File(None), # 文件是可选的
    current_user: User = Depends(get_current_active_user),
    session: Session = Depends(get_session)
):
    post_data = PostCreate(title=title, content=content) # file_path 会在服务层处理
    try:
        return db_create_post(session=session, post_data=post_data, author_id=current_user.id, file=file)
    except HTTPException as e:
        raise e
    except Exception as e:
        # Log the exception e
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error creating post: {str(e)}")


@router.get("/", response_model=List[PostRead], summary="获取帖子列表 (分页)")
async def read_posts_api(
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    session: Session = Depends(get_session)
):
    return db_get_posts(session=session, skip=skip, limit=limit)

@router.get("/{post_id}", response_model=PostRead, summary="获取指定ID的帖子详情")
async def read_post_by_id_api(post_id: int, session: Session = Depends(get_session)):
    post = db_get_post_by_id(session=session, post_id=post_id)
    if not post:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Post not found")
    return post

# --- 收藏相关 API ---
@router.post("/{post_id}/favorite", summary="收藏帖子")
async def favorite_post_api(
    post_id: int,
    current_user: User = Depends(get_current_active_user),
    session: Session = Depends(get_session)
):
    try:
        db_add_favorite(session=session, user_id=current_user.id, post_id=post_id)
        return {"message": "Post favorited successfully"}
    except HTTPException as e: # 比如帖子不存在或已收藏
        raise e
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.delete("/{post_id}/favorite", summary="取消收藏帖子")
async def unfavorite_post_api(
    post_id: int,
    current_user: User = Depends(get_current_active_user),
    session: Session = Depends(get_session)
):
    try:
        return db_remove_favorite(session=session, user_id=current_user.id, post_id=post_id)
    except HTTPException as e: # 比如收藏不存在
        raise e
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/favorites/my", response_model=List[PostRead], summary="获取当前用户收藏的所有帖子")
async def get_my_favorites_api(
    current_user: User = Depends(get_current_active_user),
    session: Session = Depends(get_session)
):
    return db_get_user_favorites(session=session, user_id=current_user.id)

@router.get("/{post_id}/is_favorite", response_model=bool, summary="检查当前用户是否收藏了某帖子")
async def check_is_favorite_api(
    post_id: int,
    current_user: User = Depends(get_current_active_user),
    session: Session = Depends(get_session)
):
    return db_is_user_favor_post(session=session, user_id=current_user.id, post_id=post_id)

# --- 单独的文件上传接口 (如果需要) ---
# 如果你希望有一个不直接关联创建帖子的通用文件上传接口（比如上传用户头像）
@router.post("/upload-file/", summary="上传通用文件 (如PDF, 图片等)")
async def upload_general_file_api(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_active_user) # 确保只有登录用户可上传
):
    # 可以在这里添加文件类型校验
    # if not file.filename.endswith('.pdf'):
    #     raise HTTPException(status_code=400, detail="File must be a PDF")
    # if file.content_type not in ["application/pdf", "image/jpeg", "image/png"]:
    #    raise HTTPException(status_code=400, detail="Unsupported file type")
    try:
        return db_upload_file_generic(user_id=current_user.id, file=file)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error uploading file: {str(e)}")
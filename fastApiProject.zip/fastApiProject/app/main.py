# app/main.py
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import os

# 导入数据库创建函数和模型，确保它们被加载
from .database import create_db_and_tables, engine # engine for potential direct use
from .models import users, posts # 导入模型模块以确保表被元数据捕获

# 导入API路由
from .api import auth as auth_router
from .api import posts as posts_router
from .config import BASE_DIR # 获取项目根目录

# 确保所有SQLModel定义的表在启动时被创建
# 这一步非常重要，因为SQLModel.metadata.create_all() 需要知道所有的模型定义
# 通过导入 users 和 posts 模块，可以确保 Python 解释器加载了这些模型类。
# 如果不导入，SQLModel.metadata 可能为空，create_db_and_tables() 不会创建任何表。


app = FastAPI(
    title="MyProject API with MySQL",
    description="一个使用FastAPI和MySQL构建的示例项目。",
    version="0.1.0"
)

# 配置CORS (跨源资源共享)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境中应指定允许的源列表, e.g., ["http://localhost:3000"]
    allow_credentials=True,
    allow_methods=["*"], # 或者指定 ["GET", "POST", "PUT", "DELETE"]
    allow_headers=["*"],
)

# 挂载静态文件目录 (用于访问上传的文件)
# UPLOAD_DIR 是 'myproject/static/uploads'
# 我们需要挂载 'myproject/static' 目录，并通过 '/static' URL 访问
# 那么 'myproject/static/uploads/file.jpg' 就可以通过 '/static/uploads/file.jpg' 访问
static_files_path = os.path.join(BASE_DIR, "static")
if not os.path.exists(static_files_path):
    os.makedirs(static_files_path)
if not os.path.exists(os.path.join(static_files_path, "uploads")): # 确保uploads子目录也存在
    os.makedirs(os.path.join(static_files_path, "uploads"))

app.mount("/static", StaticFiles(directory=static_files_path), name="static")


@app.on_event("startup")
def on_startup():
    print("Application startup: Creating database and tables if they don't exist.")
    create_db_and_tables()
    print("Startup complete.")

# 加载API路由
app.include_router(auth_router.router)
app.include_router(posts_router.router)
# app/main.py
# ... (其他导入)
from .api import auth as auth_router
from .api import posts as posts_router
from .api import recommendations as recommendations_router # <--- 新增导入

# ... (FastAPI app 实例创建等)

# 加载API路由
app.include_router(auth_router.router)
app.include_router(posts_router.router)
app.include_router(recommendations_router.router) # <--- 新增包含

# ... (其他代码, 如 on_startup, root 路径)

@app.get("/", summary="API Root", tags=["Root"])
async def root():
    return {"message": "Welcome to MyProject API with MySQL. Visit /docs for API documentation."}
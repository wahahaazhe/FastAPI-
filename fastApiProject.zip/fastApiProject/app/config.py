# app/config.py
import os
from dotenv import load_dotenv # 用于从 .env 文件加载环境变量

# --- 项目基础目录 ---
# BASE_DIR 指向项目根目录 (myproject/ 或 fastApiProject/)
# __file__ 是 D:\fastApiProject\app\config.py (示例路径)
# os.path.dirname(os.path.abspath(__file__)) 是 D:\fastApiProject\app
# os.path.dirname(os.path.dirname(os.path.abspath(__file__))) 是 D:\fastApiProject
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# --- .env 文件加载逻辑 ---
# 假设 .env 文件在项目根目录 (由 BASE_DIR 定义)
dotenv_path = os.path.join(BASE_DIR, '.env')

if os.path.exists(dotenv_path):
    load_dotenv(dotenv_path)
    # print(f".env file loaded from: {dotenv_path}") # 调试时可以取消注释
else:
    print(f"Warning: .env file not found at {dotenv_path}. Using default or OS environment variables.")


# --- 数据库配置 ---
# 优先从 .env 文件或操作系统环境变量中获取，如果没有则使用默认值
DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = os.getenv("DB_PORT", "3306")
DB_USER = os.getenv("DB_USER", "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "123456") # 你的默认密码
DB_NAME = os.getenv("DB_NAME", "myproject")         # 你的默认数据库名

# 数据库URL
# 添加 ?charset=utf8mb4 以支持更广泛的字符集
DATABASE_URL = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"

# --- JWT配置 ---
# 优先从 .env 文件或操作系统环境变量中获取
SECRET_KEY = os.getenv("SECRET_KEY", "your-default-super-secret-key-please-change-in-env")
ALGORITHM = os.getenv("ALGORITHM", "HS256") # 通常 ALGORITHM 是固定的
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 60 * 24))  # 24小时

# --- 上传配置 ---
# UPLOAD_DIR 现在使用 BASE_DIR 来构建相对于项目根的路径，确保与 main.py 中挂载静态文件一致
# 我们假设 'static' 目录位于项目根目录下 (由 BASE_DIR 指向的目录)
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads") # 例如 D:\fastApiProject\static\uploads

# 确保 UPLOAD_DIR 存在是一个好习惯，可以在应用启动时或首次使用前创建
# 例如，可以在 main.py 的 startup 事件中或者服务层函数中处理
# if not os.path.exists(UPLOAD_DIR):
#     os.makedirs(UPLOAD_DIR, exist_ok=True)
#     print(f"Created upload directory: {UPLOAD_DIR}")

# SQLModel 的导入通常不需要在这里，除非你有特定的全局 SQLModel 配置
# from sqlmodel import SQLModel # 这行可以移除，除非有特殊用途

# 打印一些配置信息以供调试 (可选，生产环境应移除)
# print(f"DATABASE_URL: {DATABASE_URL}")
# print(f"SECRET_KEY: {'*' * len(SECRET_KEY) if SECRET_KEY else 'Not Set'}") # 不直接打印敏感信息
# print(f"UPLOAD_DIR: {UPLOAD_DIR}")
# print(f"BASE_DIR: {BASE_DIR}")